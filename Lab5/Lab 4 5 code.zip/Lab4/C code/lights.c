#define switches (volatile char*) 0x00011010
#define leds ( char*) 0x00011000

//grant control of leds with switches
void main()
{
	while(1){
		*leds = *switches;
	}

}



